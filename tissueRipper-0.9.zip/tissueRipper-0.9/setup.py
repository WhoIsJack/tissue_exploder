# -*- coding: utf-8 -*-
"""
Created on Thu Dec 17 23:12:45 2015

# Author        Jonas Hartmann @ Gilmour Group @ EMBL Heidelberg

# Version:      0.9 (BETA)
                Please report bugs to jonas.hartmann@embl.de or open an issue
                on github at https://github.com/WhoIsJack/tissueRipper
                
# Descript:     Setup.py to install tissueRipper.

# License       None. You are free to use, change and redistribute this code 
                as you like. Mention of the original author is encouraged, 
                but not required.

# Warranty      This code is supplied "as is", without warranties or 
                conditions of any kind. The author takes no responsibility 
                for any inconvenience, damage or loss of data that may be 
                incurred as a result of using this code.
"""

from distutils.core import setup
setup(name='tissueRipper',
      version='0.9',
      description='Ripped Tissue Visualization Algorithm',
      author='Jonas Hartmann @ Gilmour Group @ EMBL Heidelberg',
      author_email='jonas.hartmann@embl.de',
      url='https://github.com/WhoIsJack/tissueRipper',
      py_modules=['tissueRipper'],
      )